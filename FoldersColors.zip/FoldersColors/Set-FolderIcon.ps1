param(
    [Parameter(Mandatory=$true)][string]$Folder,
    [Parameter(Mandatory=$true)][int]$IconIndex
)

# Normalize folder path (handles quotes coming from "%V")
$Folder = $Folder.Trim('"')

# Your icon library
$iconPath = "iclPath" # Paste your icl path here

if (-not (Test-Path -LiteralPath $Folder -PathType Container)) {
    throw "Target is not a folder: $Folder"
}

$desktopIni = Join-Path $Folder "desktop.ini"

$content = @"
[.ShellClassInfo]
IconResource=$iconPath,$IconIndex
IconFile=$iconPath
IconIndex=$IconIndex
"@

# Write desktop.ini (Unicode works well for desktop.ini)
Set-Content -LiteralPath $desktopIni -Value $content -Encoding Unicode -Force

# Mark folder as customizable and hide desktop.ini
attrib +s +r "$Folder"
attrib +h "$desktopIni"

# Refresh Explorer for the target folder
$shell = New-Object -ComObject Shell.Application
$ns = $shell.NameSpace($Folder)
if ($ns -and $ns.Self) { $ns.Self.InvokeVerb("refresh") }



